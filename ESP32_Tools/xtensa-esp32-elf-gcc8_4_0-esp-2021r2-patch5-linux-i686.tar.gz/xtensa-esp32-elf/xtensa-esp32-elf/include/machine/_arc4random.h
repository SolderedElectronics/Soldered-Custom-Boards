/* Use default implementation, see arc4random.h */
